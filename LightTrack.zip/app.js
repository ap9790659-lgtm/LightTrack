/* LightTrack - Hackathon Demo
   No backend required. Demo data lives in localStorage.
*/
const STORAGE_KEY = "lighttrack_reports_v1";
let currentRole = "citizen";
let reportMap, mainMap, adminMap, adminDashMap, techMap;
let reportMarker;
let selectedAssignId = null;
let currentLocation = null;
const seedReports = [];

function getReports(){
  try{
    const saved=JSON.parse(localStorage.getItem(STORAGE_KEY));
    if(saved && Array.isArray(saved)) return saved;
  }catch(e){}
  localStorage.setItem(STORAGE_KEY, JSON.stringify(seedReports));
  return seedReports;
}
function saveReports(reports){ localStorage.setItem(STORAGE_KEY, JSON.stringify(reports)); }
const IOT_KEY = "lighttrack_iot_readings_v1";
function distanceMeters(aLat, aLng, bLat, bLng) {
  const rad = value => value * Math.PI / 180;
  const dLat = rad(bLat - aLat), dLng = rad(bLng - aLng);
  const a = Math.sin(dLat/2)**2 + Math.cos(rad(aLat))*Math.cos(rad(bLat))*Math.sin(dLng/2)**2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}
function getPoleId(lat, lng, reports) {
  const nearby = reports.find(r => typeof r.lat === "number" && typeof r.lng === "number" && distanceMeters(lat,lng,r.lat,r.lng) <= 45 && r.assetId);
  if (nearby) return nearby.assetId;
  const ids = reports.map(r => Number(String(r.assetId || "").replace("SL-", ""))).filter(Number.isFinite);
  return "SL-" + Math.max(450, ...ids) + 1;
}
function addHistoryEvent(report, event, details) {
  if (!report.history) report.history = [];
  report.history.push({date:new Date().toISOString(), event, details:details || ""});
}
function readIoT() {
  try { return JSON.parse(localStorage.getItem(IOT_KEY)) || {}; } catch (_) { return {}; }
}
function simulateIoTReading() {
  const readings = readIoT();
  const voltage = Math.round(160 + Math.random()*80);
  const temperature = Math.round(35 + Math.random()*55);
  const flicker = Math.round(Math.random()*14);
  const powerFactor = +(0.55 + Math.random()*0.44).toFixed(2);
  const warning = voltage < 190 || temperature > 70 || flicker >= 8 || powerFactor < 0.75;
  readings["SL-451"] = {voltage, temperature, flicker, powerFactor, warning, checkedAt:new Date().toISOString(), maintenance: warning ? new Date(Date.now()+3*86400000).toISOString() : null};
  localStorage.setItem(IOT_KEY, JSON.stringify(readings));
  renderHotspots();
  toast(warning ? "IoT warning detected. Preventive maintenance scheduled." : "IoT reading normal. Continue monitoring.");
}
function formatDateShort(iso) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "Date unknown" : d.toLocaleDateString("en-IN", {month:"short", year:"numeric"});
}
function resetDemo(){
  if(confirm("Reset all submitted reports and start with an empty system?")){
    localStorage.removeItem(STORAGE_KEY); location.reload();
  }
}
function toast(msg){
  const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),2600);
}
function updateClock(){
  const el=document.getElementById("liveClock");
  if(el) el.textContent=new Date().toLocaleString("en-IN",{weekday:"short",day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"});
}
setInterval(updateClock,1000); updateClock();

function switchRole(role){
  currentRole=role;
  document.getElementById("roleLabel").textContent=role[0].toUpperCase()+role.slice(1);
  ["citizen","admin","technician"].forEach(r=>document.getElementById("nav-"+r).classList.toggle("hidden",r!==role));
  const start={citizen:"citizen-home",admin:"admin-dashboard",technician:"tech-dashboard"}[role];
  showPage(start);
  renderCitizenHome();
  renderMyReports();
  renderAdminDashboard();
  renderAdminComplaints();
  renderHotspots();
  renderTechDashboard();
}
function showPage(page, navBtn){
  document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
  const target=document.getElementById("page-"+page);
  if(target) target.classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.remove("active"));
  if(navBtn) navBtn.classList.add("active");
  else{
    const btn=document.querySelector(`.nav-item[data-page="${page}"]`);
    if(btn) btn.classList.add("active");
  }
  setTimeout(()=>{
    if(page==="report") initReportMap();
    if(page==="map-page") initMainMap();
    if(page==="admin-dashboard"){renderAdminDashboard();initAdminDashMap();}
    if(page==="admin-map") initAdminMap();
    if(page==="admin-complaints") renderAdminComplaints();
    if(page==="admin-hotspots") renderHotspots();
    if(page==="tech-dashboard") renderTechDashboard();
    if(page==="tech-map") initTechMap();
    if(page==="my-reports") renderMyReports();
    if(page==="citizen-home") renderCitizenHome();
  },30);
}
function toggleTheme(){document.body.classList.toggle("dark");localStorage.setItem("lighttrack_dark",document.body.classList.contains("dark"))}
if(localStorage.getItem("lighttrack_dark")==="true") document.body.classList.add("dark");

function priorityFor(severity,type,lat,lng){
  if(severity==="High" || type==="Damaged pole" || type==="Electrical issue") return "High";
  if(severity==="Medium" || type==="Flickering light") return "Medium";
  return "Low";
}
function statusClass(status){
  if(status==="Reported") return "reported";
  if(status==="Verified") return "verified";
  if(status==="Assigned") return "assigned";
  if(status==="In Progress") return "progress";
  if(status==="Repair Completed") return "completed";
  return "closed";
}
function statusLabel(status){return status}
function formatDate(){return new Date().toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}

function renderCitizenHome(){
  const reports=getReports().slice().reverse().slice(0,3);
  document.getElementById("citizenRecent").innerHTML=reports.length?reports.map(reportCard).join(""):`<div class="empty" style="grid-column:1/-1">No reports yet. Your submitted streetlight faults will appear here.</div>`;
}
function reportCard(r){
  return `<div class="report-card" onclick="openReport('${r.id}')">
    <div class="report-top"><span class="report-id">${r.id}</span><span class="priority ${r.priority.toLowerCase()}">${r.priority}</span></div>
    <h3>${escapeHtml(r.type)}</h3><p>👥 ${r.affectedCount||1} citizen(s) affected</p><p>📍 ${escapeHtml(r.location)}</p><p>🕒 ${escapeHtml(r.created)}</p>
    <div style="margin-top:11px"><span class="status ${statusClass(r.status)}">${escapeHtml(r.status)}</span></div>
  </div>`;
}
function renderMyReports(){
  const list=document.getElementById("myReportsList"), reports=getReports();
  list.innerHTML=reports.length?reports.slice().reverse().map(trackingCard).join(""):`<div class="empty">No reports yet. Report your first streetlight fault.</div>`;
}
function trackingCard(r){
  const steps=["Reported","Verified","Assigned","In Progress","Repair Completed","Verified & Closed"];
  const idx=steps.indexOf(r.status);
  return `<div class="tracking-card">
    <div class="tracking-main">
      <div><span class="report-id">${r.id}</span><h3>${escapeHtml(r.type)} <span class="priority ${r.priority.toLowerCase()}">${r.priority}</span></h3><p>📍 ${escapeHtml(r.location)} · ${r.lat.toFixed(5)}, ${r.lng.toFixed(5)}</p><p>${escapeHtml(r.description)}</p></div>
      <span class="status ${statusClass(r.status)}">${escapeHtml(r.status)}</span>
    </div>
    <div class="timeline">${steps.map((s,i)=>`<div class="step ${i<idx?"done":""} ${i===idx?"current":""}"><div class="step-dot">${i<idx?"✓":i+1}</div><span>${s}</span></div>`).join("")}</div>
    <div style="margin-top:12px;display:flex;gap:8px"><button class="action-btn" onclick="openReport('${r.id}')">View details</button>${r.technician!=="—"?`<span style="font-size:10px;color:var(--muted);padding:7px">Technician: ${escapeHtml(r.technician)}</span>`:""}</div>
  </div>`;
}

function initReportMap() {
    if (typeof L === "undefined") {
        console.error("Leaflet is not loaded.");
        return;
    }

    const mapElement = document.getElementById("reportMap");

    if (!mapElement) {
        console.error("Report map element not found.");
        return;
    }

    if (reportMap) {
        setTimeout(() => {
            reportMap.invalidateSize();
        }, 200);
        return;
    }

    const defaultLocation = [26.9124, 75.7873];

    reportMap = L.map("reportMap").setView(
        defaultLocation,
        13
    );

    L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
        {
            maxZoom: 19,
            minZoom: 3,
            attribution: "© Esri"
        }
    ).addTo(reportMap);

    reportMarker = L.marker(
        defaultLocation,
        {
            draggable: true,
            autoPan: true
        }
    ).addTo(reportMap);

    reportMarker.bindPopup(
        "Drag this marker to the fault location."
    );

    reportMarker.on("drag", function (event) {
        const position = event.target.getLatLng();

        setReportLocation(
            position.lat,
            position.lng
        );
    });

    reportMarker.on("dragend", function (event) {
        const position = event.target.getLatLng();

        setReportLocation(
            position.lat,
            position.lng
        );

        reportMarker
            .bindPopup(
                "Selected Location<br>" +
                "Latitude: " +
                position.lat.toFixed(6) +
                "<br>" +
                "Longitude: " +
                position.lng.toFixed(6)
            )
            .openPopup();
    });

    reportMap.on("click", function (event) {
        const lat = event.latlng.lat;
        const lng = event.latlng.lng;

        if (reportMarker) {
            reportMarker.setLatLng([lat, lng]);
        }

        setReportLocation(lat, lng);

        if (reportMarker) {
            reportMarker
                .bindPopup(
                    "Selected Location<br>" +
                    "Latitude: " +
                    lat.toFixed(6) +
                    "<br>" +
                    "Longitude: " +
                    lng.toFixed(6)
                )
                .openPopup();
        }
    });

    setTimeout(() => {
        if (reportMap) {
            reportMap.invalidateSize();
        }
    }, 500);
}

function setLocation(lat, lng, source, updateMarker = true) {
    currentLocation = {
        lat: lat,
        lng: lng,
        source: source
    };

    const latValue = document.getElementById("latValue");
    const lngValue = document.getElementById("lngValue");
    const locationStatus =
        document.getElementById("locationStatus");
    const locationText =
        document.getElementById("locationText");

    // Update visible latitude
    if (latValue) {
        latValue.textContent = lat.toFixed(6);
    }

    // Update visible longitude
    if (lngValue) {
        lngValue.textContent = lng.toFixed(6);
    }

    // Update location status
    if (locationStatus) {
        locationStatus.textContent = "Location captured ✓";
    }

    // Update location helper text
    if (locationText) {
        locationText.textContent =
            source +
            " — you can click/drag the pin to adjust.";
    }

    // Move marker only when required
    if (updateMarker && reportMarker) {
        reportMarker.setLatLng([lat, lng]);
    }

    // Center map on new location
    if (reportMap && updateMarker) {
        reportMap.setView([lat, lng], 15);
    }
}
function setReportLocation(lat, lng) {
    setLocation(
        lat,
        lng,
        "Manual map",
        false
    );
}
function getLocation() {

    if (!navigator.geolocation) {
        toast(
            "Geolocation is not supported. Please select the location on the map."
        );
        return;
    }

    toast("Getting your current location...");

    navigator.geolocation.getCurrentPosition(

        function (position) {

            const lat =
                position.coords.latitude;

            const lng =
                position.coords.longitude;

            setLocation(
                lat,
                lng,
                "GPS"
            );

            toast(
                "Your current location was captured successfully."
            );
        },

        function (error) {

            console.error(
                "Geolocation error:",
                error
            );

            toast(
                "Location permission denied. Select the location manually on the map."
            );
        },

        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
}
function submitReport(e) {
    e.preventDefault();

    const form = document.getElementById("reportForm");

    if (!form) {
        console.error("Report form not found.");
        return;
    }

    const type = document.getElementById("faultType")?.value;
    const severity = document.querySelector(
        'input[name="severity"]:checked'
    )?.value;

    const description =
        document.getElementById("description")?.value.trim() || "";

   const nameInput =
    document.getElementById("reporterName");

const phoneInput =
    document.getElementById("reporterPhone");

const name =
    nameInput
        ? nameInput.value.trim()
        : "";

const phone =
    phoneInput
        ? phoneInput.value.trim()
        : "";

    // Basic validation
    if (!type) {
        toast("Please select a fault type.");
        return;
    }

    if (!severity) {
        toast("Please select severity.");
        return;
    }

    if (!description) {
        toast("Please enter a description.");
        return;
    }

    if (!name) {
    toast("Please enter your name.");
    nameInput?.focus();
    return;
}

if (!phone) {
    toast("Please enter your phone number.");
    phoneInput?.focus();
    return;
}

    /*
     * If location is already selected,
     * directly create the report.
     */
    if (currentLocation) {
        createReport();
        return;
    }

    /*
     * If location is not selected,
     * try to get the user's current GPS location.
     */
    if (navigator.geolocation) {
        toast("Getting your location...");

        navigator.geolocation.getCurrentPosition(
            function (position) {
                currentLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };

                // Update latitude/longitude fields if available
                const latInput = document.getElementById("latitude");
                const lngInput = document.getElementById("longitude");

                if (latInput) {
                    latInput.value = currentLocation.lat.toFixed(6);
                }

                if (lngInput) {
                    lngInput.value = currentLocation.lng.toFixed(6);
                }

                // Update map marker if map exists
                if (reportMap) {
                    reportMap.setView(
                        [
                            currentLocation.lat,
                            currentLocation.lng
                        ],
                        16
                    );

                    if (reportMarker) {
                        reportMarker.setLatLng([
                            currentLocation.lat,
                            currentLocation.lng
                        ]);
                    }
                }

                createReport();
            },

            function () {
                toast(
                    "Location not available. Please select a location on the map."
                );
            },

            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );

        return;
    }

    toast("Please select a location on the map.");

    /*
     * Actually creates and saves the report.
     */
    function createReport() {

    const reports = getReports();

    const now = new Date();

    const id =
        "SLF-" +
        now.getFullYear() +
        "-" +
        Math.floor(10000 + Math.random() * 90000);

    const created =
        now.toLocaleDateString("en-IN") +
        " " +
        now.toLocaleTimeString("en-IN", {
            hour: "2-digit",
            minute: "2-digit"
        });

    const report = {

        id: id,

        type: type,

        severity: severity,

        description: description,

        // Reporter details
        reporter: name,

        reporterName: name,

        reporterPhone: phone,

        // Location
        lat: currentLocation.lat,

        lng: currentLocation.lng,

        location:
            currentLocation.lat.toFixed(6) +
            ", " +
            currentLocation.lng.toFixed(6),

        // Report status
        status: "Reported",

        priority:
            calculatePriority(
                type,
                severity
            ),

        technician: "—",

        // Time
        created: created,

        createdAt:
            now.toISOString(),

        // Images
        photo: null,

        afterPhoto: null,

        // Status timeline
        timeline: [
            {
                status: "Reported",
                time: now.toISOString()
            }
        ]
    };

    // Detect the same active fault reported within 35 metres and merge citizens into one case.
    const duplicate = reports.find(existing =>
        existing.type === report.type &&
        !["Repair Completed", "Verified & Closed"].includes(existing.status) &&
        typeof existing.lat === "number" && typeof existing.lng === "number" &&
        distanceMeters(report.lat, report.lng, existing.lat, existing.lng) <= 35
    );
    if (duplicate) {
        if (!duplicate.citizens) duplicate.citizens = [{name:duplicate.reporter || "Citizen", phone:duplicate.reporterPhone || ""}];
        const alreadyReported = duplicate.citizens.some(c => c.phone && c.phone === phone);
        if (!alreadyReported) duplicate.citizens.push({name, phone});
        duplicate.affectedCount = Math.max(duplicate.citizens.length, duplicate.affectedCount || 1);
        duplicate.lastDuplicateAt = now.toISOString();
        if (report.priority === "High") duplicate.priority = "High";
        saveReports(reports);
        form.reset();
        currentLocation = null;
        const latValue = document.getElementById("latValue");
        const lngValue = document.getElementById("lngValue");
        if (latValue) latValue.textContent = "—";
        if (lngValue) lngValue.textContent = "—";
        const locationStatus = document.getElementById("locationStatus");
        const locationText = document.getElementById("locationText");
        if (locationStatus) locationStatus.textContent = "Location not captured";
        if (locationText) locationText.textContent = "Click the button to use your current location.";
        renderCitizenHome(); renderMyReports(); renderAdminDashboard(); renderAdminComplaints(); renderHotspots(); renderTechDashboard(); renderAllMaps();
        toast(`Duplicate detected: ${duplicate.id} now shows ${duplicate.affectedCount} affected citizen(s).`);
        showPage("my-reports");
        return;
    }

    report.assetId = getPoleId(report.lat, report.lng, reports);
    report.affectedCount = 1;
    report.citizens = [{name, phone}];
    report.history = [{date:now.toISOString(), event:"Fault reported", details:type}];

    // Add newest report
    reports.unshift(report);

    // Save report
    saveReports(reports);

    // Success message
    toast(
        "Fault report submitted successfully!"
    );

    // Reset form
    form.reset();

    // Reset selected location
    currentLocation = null;

    // Reset map marker
    if (reportMarker) {
    reportMarker.setLatLng(
        [26.9124, 75.7873]
    );
}

    // Reset map
    if (reportMap) {
    reportMap.setView(
        [26.9124, 75.7873],
        13
    );
}

    // Reset coordinates
    const latValue =
        document.getElementById("latValue");

    const lngValue =
        document.getElementById("lngValue");

    const locationStatus =
        document.getElementById(
            "locationStatus"
        );

    const locationText =
        document.getElementById(
            "locationText"
        );

    if (latValue) {
        latValue.textContent = "—";
    }

    if (lngValue) {
        lngValue.textContent = "—";
    }

    if (locationStatus) {
        locationStatus.textContent =
            "Location not captured";
    }

    if (locationText) {
        locationText.textContent =
            "Click the button to use your current location.";
    }

    // Refresh Citizen pages
    renderCitizenHome();

    renderMyReports();

    // Refresh Admin pages
    renderAdminDashboard();

    renderAdminComplaints();

    renderHotspots();

    // Refresh Technician page
    renderTechDashboard();

    // Refresh all existing maps
    renderAllMaps();

    // Open My Reports
    showPage("my-reports");
}
}

function calculatePriority(type, severity) {
    if (severity === "Critical") {
        return "High";
    }

    if (severity === "High") {
        return "High";
    }

    if (type === "Electrical Shock Risk") {
        return "High";
    }

    if (severity === "Medium") {
        return "Medium";
    }

    return "Low";
}

function getFilteredReports(){
  const filter=document.getElementById("mapFilter")?.value||"all";
  return getReports().filter(r=>{
    if(filter==="open") return !["Repair Completed","Verified & Closed"].includes(r.status);
    if(filter==="progress") return ["Assigned","In Progress"].includes(r.status);
    if(filter==="closed") return ["Repair Completed","Verified & Closed"].includes(r.status);
    return true;
  });
}
function markerColor(r){
  if(r.status==="Verified & Closed") return "#22c55e";
  if(r.status==="In Progress"||r.status==="Assigned"||r.status==="Repair Completed") return "#f59e0b";
  return r.priority==="High"?"#ef4444":"#f59e0b";
}
function makeMarker(r){
  const icon=L.divIcon({className:"custom-marker",html:`<div style="width:15px;height:15px;border-radius:50%;background:${markerColor(r)};border:3px solid white;box-shadow:0 2px 8px #0005"></div>`,iconSize:[15,15],iconAnchor:[7,7]});
  return L.marker([r.lat,r.lng],{icon}).bindPopup(`<b>${r.id}</b><br>${escapeHtml(r.type)}<br>📍 ${escapeHtml(r.location)}<br><span style="font-weight:700">${escapeHtml(r.status)}</span><br><button onclick="openReport('${r.id}')" style="margin-top:7px;border:0;background:#2563eb;color:white;border-radius:5px;padding:5px 8px">View report</button>`);
}
function drawMarkers(map, reports) {

    if (!map) return;

    // Remove only markers belonging to THIS map
    if (map._lightTrackMarkers) {
        map._lightTrackMarkers.forEach(marker => {
            map.removeLayer(marker);
        });
    }

    map._lightTrackMarkers = [];

    // Add reports to this map
    reports.forEach(report => {

        if (
            typeof report.lat !== "number" ||
            typeof report.lng !== "number"
        ) {
            return;
        }

        const marker = makeMarker(report).addTo(map);

        map._lightTrackMarkers.push(marker);
    });

    // Automatically show the available reports
    if (reports.length === 1) {

        map.setView(
            [reports[0].lat, reports[0].lng],
            15
        );

    } else if (reports.length > 1) {

        const bounds = L.latLngBounds(
            reports.map(report => [
                report.lat,
                report.lng
            ])
        );

        map.fitBounds(bounds, {
            padding: [40, 40],
            maxZoom: 15
        });
    }
}
function initMainMap() {
    if (typeof L === "undefined") {
        console.error("Leaflet is not loaded.");
        return;
    }

    const mapElement = document.getElementById("mainMap");

    if (!mapElement) {
        console.error("mainMap element not found.");
        return;
    }

    if (mainMap) {
        setTimeout(() => {
            mainMap.invalidateSize();
            drawMarkers(mainMap, getFilteredReports());
        }, 200);
        return;
    }

    mainMap = L.map("mainMap", {
        center: [26.9124, 75.7873],
        zoom: 13,
        zoomControl: true
    });

    L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
        {
            maxZoom: 19,
            minZoom: 3,
            attribution:  "© Esri"
        }
    ).addTo(mainMap);

    drawMarkers(mainMap, getFilteredReports());

    setTimeout(() => {
        mainMap.invalidateSize();
    }, 500);
}
function renderAllMaps() {

    if (mainMap) {
        drawMarkers(
            mainMap,
            getFilteredReports()
        );
    }

    if (adminMap) {
        drawMarkers(
            adminMap,
            getReports()
        );
    }

    if (adminDashMap) {
        drawMarkers(
            adminDashMap,
            getReports()
        );
    }

    if (techMap) {
        drawMarkers(
            techMap,
            getReports().filter(
                r => r.technician &&
                     r.technician !== "—"
            )
        );
    }
}
function initAdminMap() {
    if (typeof L === "undefined") {
        console.error("Leaflet is not loaded.");
        return;
    }

    const mapElement = document.getElementById("adminMap");

    if (!mapElement) {
        console.error("adminMap element not found.");
        return;
    }

    if (adminMap) {
        setTimeout(() => {
            adminMap.invalidateSize();
            drawMarkers(adminMap, getReports());
        }, 200);
        return;
    }

    adminMap = L.map("adminMap", {
        center: [26.9124, 75.7873],
        zoom: 13,
        zoomControl: true
    });

    L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
        {
            maxZoom: 19,
            minZoom: 3,
            attribution:  "© Esri"
        }
    ).addTo(adminMap);

    drawMarkers(adminMap, getReports());

    setTimeout(() => {
        adminMap.invalidateSize();
    }, 500);
}
function initAdminDashMap() {
    if (typeof L === "undefined") {
        console.error("Leaflet is not loaded.");
        return;
    }

    const mapElement = document.getElementById("adminDashMap");

    if (!mapElement) {
        console.error("adminDashMap element not found.");
        return;
    }

    if (adminDashMap) {
        setTimeout(() => {
            adminDashMap.invalidateSize();
            drawMarkers(adminDashMap, getReports());
        }, 200);
        return;
    }

    adminDashMap = L.map("adminDashMap", {
        center: [26.9124, 75.7873],
        zoom: 13,
        zoomControl: true
    });

    L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
        {
            maxZoom: 19,
            minZoom: 3,
            attribution:  "© Esri"
        }
    ).addTo(adminDashMap);

    drawMarkers(adminDashMap, getReports());

    setTimeout(() => {
        adminDashMap.invalidateSize();
    }, 500);
}
function initTechMap() {
    if (typeof L === "undefined") {
        console.error("Leaflet is not loaded.");
        return;
    }

    const mapElement = document.getElementById("techMap");

    if (!mapElement) {
        console.error("techMap element not found.");
        return;
    }

    const assignedReports = getReports().filter(
        r => r.technician && r.technician !== "—"
    );

    if (techMap) {
        setTimeout(() => {
            techMap.invalidateSize();
            drawMarkers(techMap, assignedReports);
        }, 200);
        return;
    }

    techMap = L.map("techMap", {
        center: [26.9124, 75.7873],
        zoom: 13,
        zoomControl: true
    });

    L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
        {
            maxZoom: 19,
            minZoom: 3,
            attribution: "&copy; OpenStreetMap contributors"
        }
    ).addTo(techMap);

    drawMarkers(techMap, assignedReports);

    setTimeout(() => {
        techMap.invalidateSize();
    }, 500);
}

function renderAdminDashboard(){
  const rs=getReports(), total=rs.length, open=rs.filter(r=>!["Verified & Closed"].includes(r.status)).length;
  const inProg=rs.filter(r=>["Assigned","In Progress","Repair Completed"].includes(r.status)).length;
  const closed=rs.filter(r=>r.status==="Verified & Closed").length;
  document.getElementById("adminStats").innerHTML=[
    ["Total Faults",total,"Reports submitted"],
    ["Pending",open,"Need attention"],
    ["In Progress",inProg,"Technician workload"],
    ["Verified / Closed",closed,"Completed successfully"]
  ].map(x=>`<div class="stat"><div class="stat-label">${x[0]}</div><div class="stat-value">${x[1]}</div><div class="stat-foot">${x[2]}</div></div>`).join("");
  const high=rs.filter(r=>r.priority==="High"&&r.status!=="Verified & Closed").sort((a,b)=>a.created.localeCompare(b.created)).slice(0,5);
  document.getElementById("priorityQueue").innerHTML=high.length?high.map(r=>`<div class="queue-row"><div><div class="queue-title">${r.id} · ${escapeHtml(r.type)}</div><div class="queue-sub">📍 ${escapeHtml(r.location)}</div></div><span class="priority high">HIGH</span></div>`).join(""):`<div class="empty">No high-priority open faults.</div>`;
  const repaired=rs.filter(r=>["Repair Completed","Verified & Closed"].includes(r.status)).length;
  const rate=rs.length?Math.round((repaired/rs.length)*100):0;
  const assignedOrDone=rs.filter(r=>r.technician && r.technician!=="—").length;
  const assignmentRate=rs.length?Math.round((assignedOrDone/rs.length)*100):0;
  document.getElementById("performanceBox").innerHTML=`<div class="perf-row"><div class="perf-label"><span>Repair completion</span><strong>${rate}%</strong></div><div class="progress-bar"><div class="progress-fill" style="width:${rate}%"></div></div></div><div class="perf-row"><div class="perf-label"><span>Technician assignment</span><strong>${assignmentRate}%</strong></div><div class="progress-bar"><div class="progress-fill" style="width:${assignmentRate}%"></div></div></div><p class="muted">${rs.length?`Live metrics are calculated from ${rs.length} submitted report${rs.length===1?"":"s"}.`:"No reports yet. Metrics will appear after the first report is submitted."}</p>`;
}
function renderAdminComplaints(){
  const search=(document.getElementById("adminSearch")?.value||"").toLowerCase();
  const status=document.getElementById("adminStatus")?.value||"all", priority=document.getElementById("adminPriority")?.value||"all";
  const rows=getReports().filter(r=>(status==="all"||r.status===status)&&(priority==="all"||r.priority===priority)&&(!search||`${r.id} ${r.type} ${r.location}`.toLowerCase().includes(search)));
  document.getElementById("adminTable").innerHTML=rows.map(r=>`<tr>
    <td><strong>${r.id}</strong><br><span style="color:var(--muted)">${r.created}</span></td>
    <td>${escapeHtml(r.type)}<br><span style="color:var(--muted)">${escapeHtml(r.severity)} · ${r.affectedCount||1} affected</span><br><span class="badge neutral">${escapeHtml(r.assetId||"Pole ID pending")}</span></td>
    <td>📍 ${escapeHtml(r.location)}<br><span style="color:var(--muted)">${r.lat.toFixed(4)}, ${r.lng.toFixed(4)}</span></td>
    <td><span class="priority ${r.priority.toLowerCase()}">${r.priority}</span></td>
    <td><span class="status ${statusClass(r.status)}">${r.status}</span></td>
    <td>${escapeHtml(r.technician)}</td>
    <td><button class="action-btn" onclick="openAdminAction('${r.id}')">${r.technician==="—"?"Assign":"Manage"}</button></td>
  </tr>`).join("")||`<tr><td colspan="7"><div class="empty">No matching complaints.</div></td></tr>`;
}
function openAdminAction(id){
  const r=getReports().find(x=>x.id===id); if(!r)return;
  if(r.technician==="—"){selectedAssignId=id;document.getElementById("assignComplaintLabel").textContent=`${r.id} · ${r.type} · ${r.location}`;document.getElementById("assignModal").classList.remove("hidden");}
  else openReport(id,true);
}
function closeAssignModal(){document.getElementById("assignModal").classList.add("hidden");selectedAssignId=null}
function confirmAssign(){
  const reports=getReports(),r=reports.find(x=>x.id===selectedAssignId);if(!r)return;
  const technician=document.getElementById("technicianSelect").value.trim();
  if(!technician){toast("Enter a technician name first.");return;}
  r.technician=technician;r.status="Assigned";saveReports(reports);closeAssignModal();toast(`${r.id} assigned to ${r.technician}.`);renderAdminComplaints();renderAdminDashboard();
}
function renderHotspots(){
  const rs=getReports(), counts={};
  rs.forEach(r=>counts[r.hotspot||r.location]=(counts[r.hotspot||r.location]||0)+1);
  const sorted=Object.entries(counts).sort((a,b)=>b[1]-a[1]), max=Math.max(...sorted.map(x=>x[1]),1);
  const hotspotHtml=sorted.map(([name,count])=>`<div class="hotspot"><div class="hotspot-head"><span>📍 ${escapeHtml(name)}</span><span>${count} faults</span></div><div class="hotspot-bar"><span style="width:${Math.max(10,count/max*100)}%"></span></div><div class="hotspot-note">${count>=2?"Repeated failures — consider preventive inspection.":"Low-volume area — monitor."}</div></div>`).join("") || `<div class="empty">No citizen fault reports yet.</div>`;
  const iot=readIoT()["SL-451"];
  const iotHtml=iot ? `<div class="stats-grid" style="margin-top:12px"><div class="stat"><div class="stat-label">Voltage</div><div class="stat-value">${iot.voltage} V</div><div class="stat-foot">Target 200–240 V</div></div><div class="stat"><div class="stat-label">Temperature</div><div class="stat-value">${iot.temperature}°C</div><div class="stat-foot">Warning above 70°C</div></div><div class="stat"><div class="stat-label">Flicker events</div><div class="stat-value">${iot.flicker}</div><div class="stat-foot">Warning at 8+</div></div><div class="stat"><div class="stat-label">Power factor</div><div class="stat-value">${iot.powerFactor}</div><div class="stat-foot">Warning below 0.75</div></div></div><p style="margin-top:12px"><span class="status ${iot.warning?'reported':'completed'}">${iot.warning?'⚠ Early warning detected':'✓ Readings normal'}</span> <span class="muted">Last simulated reading: ${new Date(iot.checkedAt).toLocaleString('en-IN')}</span></p>${iot.warning?`<div class="queue-row"><div><div class="queue-title">Preventive maintenance scheduled</div><div class="queue-sub">Pole SL-451 · ${formatDateShort(iot.maintenance)} · Inspect driver, wiring and lamp before failure.</div></div><span class="priority high">SCHEDULED</span></div>`:''}` : `<div class="empty">No sensor readings yet. Use the button to simulate a connected IoT sensor.</div>`;
  const historyRows=[];
  rs.forEach(r=>{(r.history||[{date:r.createdAt||"",event:"Fault reported",details:r.type}]).forEach(h=>historyRows.push({assetId:r.assetId||"Unassigned pole",date:h.date,event:h.event,details:h.details||r.type,id:r.id}));});
  const historyHtml=historyRows.length ? historyRows.sort((a,b)=>String(b.date).localeCompare(String(a.date))).map(h=>`<tr><td><strong>${escapeHtml(h.assetId)}</strong></td><td>${escapeHtml(formatDateShort(h.date))}</td><td>${escapeHtml(h.event)}</td><td>${escapeHtml(h.details)}</td><td>${escapeHtml(h.id)}</td></tr>`).join("") : `<tr><td colspan="5">No real repair history yet. When technicians complete repairs, events will appear here.</td></tr>`;
  document.getElementById("hotspotContent").innerHTML=`<div class="hotspot-grid"><div class="card"><div class="card-head"><h3>Top fault hotspots</h3><span class="badge neutral">Auto calculated</span></div><div class="hotspot-list" style="margin-top:14px">${hotspotHtml}</div></div><div class="card"><div class="card-head"><h3>What this tells the authority</h3></div><div style="margin-top:15px"><div class="queue-row"><div><div class="queue-title">1. Prioritize repeated failures</div><div class="queue-sub">Send maintenance teams to areas with multiple complaints.</div></div></div><div class="queue-row"><div><div class="queue-title">2. Detect infrastructure issues</div><div class="queue-sub">Repeated faults can indicate wiring or power problems.</div></div></div><div class="queue-row"><div><div class="queue-title">3. Plan preventive maintenance</div><div class="queue-sub">Use pole-level history to schedule inspections.</div></div></div></div></div></div>
  <div class="card" style="margin-top:18px"><div class="card-head"><div><h3>📡 IoT predictive maintenance</h3><p class="muted">Demo sensor telemetry for pole SL-451</p></div><button class="primary-btn" onclick="simulateIoTReading()">Simulate sensor reading</button></div><p class="muted">A real deployment needs sensors/current-voltage telemetry and a device gateway. This demo generates sample readings locally.</p>${iotHtml}</div>
  <div class="card" style="margin-top:18px"><div class="card-head"><div><h3>🧾 Recurring fault history</h3><p class="muted">Every reported fault and repair event is tied to a pole ID.</p></div></div><div class="table-wrap"><table><thead><tr><th>Pole ID</th><th>Month</th><th>Event</th><th>Fault / repair detail</th><th>Complaint ID</th></tr></thead><tbody>${historyHtml}<tr><td><strong>SL-451</strong></td><td>Jan 2026</td><td>Historical demo</td><td>Driver failure</td><td>DEMO-001</td></tr><tr><td><strong>SL-451</strong></td><td>Mar 2026</td><td>Historical demo</td><td>Light failure</td><td>DEMO-002</td></tr><tr><td><strong>SL-451</strong></td><td>Jun 2026</td><td>Historical demo</td><td>Pole broken</td><td>DEMO-003</td></tr></tbody></table></div></div>`;
}
function renderTechDashboard(){
  const rs=getReports(), mine=rs.filter(r=>r.technician);
  document.getElementById("techStats").innerHTML=[["Assigned",mine.filter(r=>r.status==="Assigned").length,"New tasks"],["In Progress",mine.filter(r=>r.status==="In Progress").length,"Currently repairing"],["Completed",mine.filter(r=>["Repair Completed","Verified & Closed"].includes(r.status)).length,"Repair proof submitted"]].map(x=>`<div class="stat"><div class="stat-label">${x[0]}</div><div class="stat-value">${x[1]}</div><div class="stat-foot">${x[2]}</div></div>`).join("");
  document.getElementById("techTasks").innerHTML=mine.map(techTask).join("")||`<div class="empty">No technician tasks yet. Admin assignment will make tasks appear here automatically.</div>`;
}
function techTask(r){
  const active=["Assigned","In Progress"].includes(r.status);
  return `<div class="task-card"><div class="task-head"><div><span class="report-id">${r.id}</span><h3>${escapeHtml(r.type)}</h3><p class="muted">📍 ${escapeHtml(r.location)} · Priority: <b>${r.priority}</b></p></div><span class="status ${statusClass(r.status)}">${r.status}</span></div>
  <div class="task-details"><div class="detail-box"><span>Coordinates</span><strong>${r.lat.toFixed(5)}, ${r.lng.toFixed(5)}</strong></div><div class="detail-box"><span>Reported</span><strong>${r.created}</strong></div><div class="detail-box"><span>Severity</span><strong>${r.severity}</strong></div></div>
  <p class="muted">${escapeHtml(r.description)}</p>
  <div class="task-actions">${active?`<button class="secondary-btn" onclick="navigateTo('${r.id}')">↗ Navigate</button><button class="primary-btn" onclick="startRepair('${r.id}')">${r.status==="Assigned"?"Start repair":"Submit repair"}</button>`:`<button class="secondary-btn" onclick="openReport('${r.id}')">View report</button>`}</div>
  ${r.status==="In Progress"?`<div class="repair-proof"><div class="field"><label>Upload repair proof (after photo)</label><input type="file" accept="image/*" onchange="uploadAfterPhoto('${r.id}',this)"></div></div>`:""}
  ${r.afterPhoto?`<div class="proof-preview"><img src="${r.afterPhoto}"><div><b style="font-size:11px">Repair proof uploaded ✓</b><p class="muted">Awaiting admin verification.</p></div></div>`:""}
  </div>`;
}
function startRepair(id){
  const rs=getReports(),r=rs.find(x=>x.id===id);if(!r)return;
  if(r.status==="Assigned"){r.status="In Progress";saveReports(rs);toast("Task moved to In Progress.");renderTechDashboard();}
  else if(r.status==="In Progress"){toast("Upload an after-repair photo to submit proof.");}
}
function uploadAfterPhoto(id,input){
  const file=input.files[0];if(!file)return;const reader=new FileReader();reader.onload=()=>{
    const rs=getReports(),r=rs.find(x=>x.id===id);r.afterPhoto=reader.result;r.status="Repair Completed";addHistoryEvent(r,"Repair completed",`Repair proof uploaded for ${r.type}`);saveReports(rs);toast("Repair proof uploaded. Status: Repair Completed.");renderTechDashboard();
  };reader.readAsDataURL(file);
}
function navigateTo(id){
  const r=getReports().find(x=>x.id===id);if(!r)return;
  window.open(`https://www.google.com/maps/dir/?api=1&destination=${r.lat},${r.lng}`,"_blank");
}
function openReport(id,admin=false){
  const r=getReports().find(x=>x.id===id);if(!r)return;
  const content=`<span class="eyebrow">${r.id}</span><h2>${escapeHtml(r.type)}</h2><div style="margin-top:6px"><span class="status ${statusClass(r.status)}">${r.status}</span> <span class="priority ${r.priority.toLowerCase()}">${r.priority} priority</span></div>
  <div class="detail-grid"><div><span>Pole ID</span><strong>${escapeHtml(r.assetId||"Not assigned")}</strong></div><div><span>Affected citizens</span><strong>${r.affectedCount||1}</strong></div><div><span>Location</span><strong>${escapeHtml(r.location)}</strong></div><div><span>Coordinates</span><strong>${r.lat.toFixed(6)}, ${r.lng.toFixed(6)}</strong></div><div><span>Severity</span><strong>${r.severity}</strong></div><div><span>Technician</span><strong>${escapeHtml(r.technician)}</strong></div><div><span>Reported</span><strong>${escapeHtml(r.created)}</strong></div><div><span>Reporter</span><strong>${escapeHtml(r.reporter)}</strong></div></div>
  <p class="muted"><b>Description</b><br>${escapeHtml(r.description)}</p>
  ${r.photo?`<div style="margin-top:12px"><b style="font-size:11px">Citizen photo</b><br><img src="${r.photo}" style="width:100%;max-height:220px;object-fit:cover;border-radius:10px;margin-top:7px"></div>`:""}
  ${r.afterPhoto?`<div style="margin-top:12px"><b style="font-size:11px">After-repair proof</b><br><img src="${r.afterPhoto}" style="width:100%;max-height:220px;object-fit:cover;border-radius:10px;margin-top:7px"></div>`:""}
  <div class="modal-actions">${admin&&r.status==="Repair Completed"?`<button class="primary-btn" onclick="verifyClose('${r.id}')">Verify & close</button>`:""}${admin&&r.technician==="—"?`<button class="primary-btn" onclick="closeModal();selectedAssignId='${r.id}';document.getElementById('assignComplaintLabel').textContent='${r.id} · ${r.type}';document.getElementById('assignModal').classList.remove('hidden')">Assign technician</button>`:""}<button class="secondary-btn" onclick="closeModal()">Close</button></div>`;
  document.getElementById("modalContent").innerHTML=content.replace("verifyClose('${r.id')",`verifyClose('${r.id}')`);
  document.getElementById("detailModal").classList.remove("hidden");
}
function verifyClose(id){
  const rs=getReports(),r=rs.find(x=>x.id===id);if(!r)return;r.status="Verified & Closed";addHistoryEvent(r,"Repair verified & closed",`Verified by admin after ${r.type}`);saveReports(rs);closeModal();toast(`${id} verified and closed.`);renderAdminDashboard();renderAdminComplaints();
}
function closeModal(){document.getElementById("detailModal").classList.add("hidden")}
function escapeHtml(str){return String(str??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

window.addEventListener("resize",()=>[reportMap,mainMap,adminMap,adminDashMap,techMap].forEach(m=>{if(m)m.invalidateSize()}));
window.addEventListener("storage",(e)=>{
  if(e.key===STORAGE_KEY){
    renderCitizenHome(); renderMyReports(); renderAdminDashboard(); renderAdminComplaints(); renderHotspots(); renderTechDashboard();
    if(mainMap) drawMarkers(mainMap,getFilteredReports());
    if(adminMap) drawMarkers(adminMap,getReports());
    if(adminDashMap) drawMarkers(adminDashMap,getReports());
    if(techMap) drawMarkers(techMap,getReports().filter(r=>r.technician));
  }
});

document.addEventListener("DOMContentLoaded",()=>{
  getReports(); renderCitizenHome(); initReportMap();
});
